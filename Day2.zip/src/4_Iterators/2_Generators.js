function* idGenerator() {
    console.log("First Line");
    yield 1;
    console.log("Paused 1");
    yield 2;
    console.log("Paused 2");
    yield 3;
    console.log("Paused 3");
}

let seq = idGenerator();

// console.log(seq.next());

do {
    var obj = seq.next();
    console.log(obj);
} while (!obj.done);