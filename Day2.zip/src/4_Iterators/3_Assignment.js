// function fibonacci(n) {
//     let [a, b] = [0, 1];

//     let result = [];
//     while (a < n) {
//         result.push(a);
//         [a, b] = [b, a + b];
//     }

//     return result;
// }

function* fibonacci(n) {
    let [a, b] = [0, 1];

    while (a < n) {
        yield a;
        [a, b] = [b, a + b];
    }
}

for (const n of fibonacci(15)) {
    console.log(n);
}