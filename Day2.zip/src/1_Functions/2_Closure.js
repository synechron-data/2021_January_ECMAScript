// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// count = "ABC";
// console.log(next());

// ----------------------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());

// ----------------------------------------------

// const next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());

// ----------------------------------------------

// const counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.next());

// console.log(counter.prev());
// console.log(counter.prev());

// ----------------------------------------------

function getCounter(by) {
    var count = 0;
    var by = by || 1;

    return {
        next: function () {
            return count += by;
        },
        prev: function () {
            return count -= by;
        }
    };
}

var cnt1 = getCounter();
console.log(cnt1.next());
console.log(cnt1.next());
console.log(cnt1.next());
console.log(cnt1.prev());
console.log(cnt1.prev());

console.log("\n");
var cnt5 = getCounter(5);
console.log(cnt5.next());
console.log(cnt5.next());
console.log(cnt5.next());
console.log(cnt5.prev());
console.log(cnt5.prev());