var firstMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ first: 'From first method' });
        }, 2000);
    });
    return promise;
};

var secondMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('second method completed');
            resolve({ second: 'From second method' });
            // reject("Second Method Failed...");
        }, 2000);
    });
    return promise;
};

var thirdMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('third method completed');
            resolve({ third: 'From third method' });
        }, 3000);
    });
    return promise;
};

Promise.all([firstMethod(), secondMethod(), thirdMethod()]).then(data=>{
    console.log("Final Result: ", data);
}).catch(eMsg => {
    console.error(eMsg);
});

// --------------------------------------------------------------------

// var firstMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('first method completed');
//             resolve({ first: 'From first method' });
//         }, 2000);
//     });
//     return promise;
// };

// var secondMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('second method completed');
//             resolve({ second: 'From second method' });
//             // reject("Second Method Failed...");
//         }, 2000);
//     });
//     return promise;
// };

// var thirdMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('third method completed');
//             resolve({ third: 'From third method' });
//         }, 3000);
//     });
//     return promise;
// };

// Promise.race([firstMethod(), secondMethod(), thirdMethod()]).then(data => {
//     console.log("Final Result: ", data);
// }).catch(eMsg => {
//     console.error(eMsg);
// });