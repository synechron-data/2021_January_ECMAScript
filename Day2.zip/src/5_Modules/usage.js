// Case 1 - Default Import
// import square from './lib';
// console.log("Square: ", square(20));

// import sqr from './lib';
// console.log("Square: ", sqr(20));

// Case 2 - Multiple Import - Named Imports
// import { square, check } from './lib';
// console.log("Square: ", square(20));
// console.log("Checked: ", check(20));

// import * as lib from './lib';
// console.log("Square: ", lib.square(20));
// console.log("Checked: ", lib.check(20));

// Case 3 - Default and Named Imports 
// import square, { check } from './lib';
// console.log("Square: ", square(20));
// console.log("Checked: ", check(20));

// import sqr, { check } from './lib';
// console.log("Square: ", sqr(10));
// console.log("Checked: ", check(20));

// -------------- Assignment
import Person from './lib';

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());