// var toy1 = new Object();
// // console.log(toy1);
// // console.log(typeof toy1);

// console.log(toy1.constructor);
// console.log(toy1.toString());

// // __proto__ - Dunder Proto
// console.log(Object.prototype === toy1.__proto__);

// -------------------------------------------------------------

var toy1 = new Object();
var toy2 = new Object();

Object.prototype.color = 'red';
Object.prototype.shape = 'circle';

Object.prototype.test = function () {
    console.log("Function Added on prototype");
};

toy1.test();
toy2.test();

// console.log("Toy 1 Color: ", toy1.color);
// console.log("Toy 1 Shape: ", toy1.shape);

// console.log("Toy 2 Color: ", toy2.color);
// console.log("Toy 2 Shape: ", toy2.shape);

// // console.log(toy1);
// // console.log(toy2);

// toy1.color = "blue";
// toy1.shape = "square";

// console.log("Toy 1 Color: ", toy1.color);
// console.log("Toy 1 Shape: ", toy1.shape);

// console.log("Toy 2 Color: ", toy2.color);
// console.log("Toy 2 Shape: ", toy2.shape);

// console.log(toy1);
// console.log(toy2);