var map = new Map();
var wmap = new WeakMap();

map.set(1, "This is the value for number key");

// WeakMap - key is always an object
const o = { id: 1 };
wmap.set(o, "This is the value for object key");

for (const item of map) {
    console.log(item);
}

// WeakMap is not iterable
// for (const item of wmap) {
//     console.log(item);
// }

// console.log(wmap.get(o));