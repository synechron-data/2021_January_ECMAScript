var myMap = new Map();

// console.log(myMap);
// console.log(typeof myMap);
const o = {};
const f = function () { };

myMap.set('the string', "This is value for the string key");
myMap.set(o, "This is value for the object key");
myMap.set(f, "This is value for the function key");

// console.log(myMap);
// console.log(myMap.size);

// console.log(myMap.get('the string'));
// console.log(myMap.get(o));
// console.log(myMap.get(f));

// for (const pair of myMap) {
//     console.log(pair);
// }

// for (const [key, value] of myMap) {
//     console.log(`${key}             ${value}`);
// }

// for (const key of myMap.keys()) {
//     console.log(`${key}`);
// }

for (const value of myMap.values()) {
    console.log(`${value}`);
}
