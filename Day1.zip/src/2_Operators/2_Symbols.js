// const Read = "Read";
// const Write = "Write";

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.error('INVALID File Mode');
// }

// Open(Read);
// Open(Write);

// Open("Read");
// Open("Write");

// var rMode = "Read";
// Open(rMode);

// var wMode = "Write";
// Open(wMode);

// --------------------------------------------------------------------

// const Read = { mode: "Read" };
// const Write = { mode: "Write" };

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.error('INVALID File Mode');
// }

// Open(Read);
// Open(Write);

// Open({ mode: "Read" });
// Open({ mode: "Write" });

// var rMode = { mode: "Read" };
// Open(rMode);

// var wMode = { mode: "Write" };
// Open(wMode);

// // --------------------------------------------------------------------

// const Read = Symbol("Read");
// const Write = Symbol("Write");

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.error('INVALID File Mode');
// }

// Open(Read);
// Open(Write);

// Open(Symbol("Read"));
// Open(Symbol("Write"));

// var rMode = Symbol("Read");
// Open(rMode);

// var wMode = Symbol("Write");
// Open(wMode);

// var o = { id: 1, username: "Manish", password: "Manish" };
// console.log(JSON.stringify(o));

var o1 = { id: 1, username: "Manish", [Symbol('password')]: "Manish" };
// console.log(o1);

// Symbol-keyed properties will be completely ignored when using JSON.stringify()
// console.log(JSON.stringify(o1));

// Symbols are not enumerable in for...in iterations
for (let i in o1) {
    console.log(i);
}
