var a = 45;
var b = "45";

// console.log(a);
// console.log(typeof a);

// console.log(b);
// console.log(typeof b);

// var r1 = a == b;        // Abstract Equality
// console.log(r1);

// var r2 = a === b;        // Strict Equality
// console.log(r2);

var obj1 = new Object();
var obj2 = new Object();
var obj3 = obj1;

console.log(obj1 == obj2);
console.log(obj1 === obj2);

console.log(obj1 == obj3);
console.log(obj1 === obj3);