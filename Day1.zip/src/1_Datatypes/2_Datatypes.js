var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = 10;          // Base 10 (Decimal)
// language = 10.5;          // Base 10 (Decimal)
// language = 0b1001;          // Base 2 (Binary)
// language = 0o1001;          // Base 8 (Octal)
// language = 0x1001;          // Base 16 (Hex)
// language = Number("1001");
language = parseInt("1001", 2);
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';

// ECMAScript 2015 - Template (String) Literals (Multipline String)
// language = `Java

//     Script`;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

var fname = "Synechron";
var message = "Hello";
// language = message + ", " + fname;
language = `${message}, ${fname}`;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// ECMAScript 2015 - Symbol

language = Symbol("Hello");
// language = new Symbol("Hello");         // Error - Symbol is not a constructor
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Object();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Date();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// RegEx
// Array
// Map
// WeakMap
// Set
// WekSet
// Promise
// Proxy