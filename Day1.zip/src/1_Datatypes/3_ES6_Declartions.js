// Block Scoped Variables

// let a;
// a = 10;
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is not allowed with let keyword
// a = 10;
// console.log("a is: ", a);
// let a;

// We cannot redeclare a block scoped variable
// let a = 10;
// let a = "Abhijeet";
// console.log("a is: ", a);

// ----------------------------------------------
// const must be initialized and it cannot be re-initialized

// const env = "development";
// console.log(env);

// env = "production";
// console.log(env);

const person = { id: 1, name: "Manish" };
console.log(person);

// person = {};                 // Error

person.name = "Abhijeet";
console.log(person);
