// import './1_Datatypes/1_Declarations';
// import './1_Datatypes/2_Datatypes';
// import './1_Datatypes/3_ES6_Declartions';
// import './1_Datatypes/4_Scopes';

// import './2_Operators/1_Comparision';
// import './2_Operators/2_Symbols';
// import './2_Operators/3_DataCoversion';

// import './3_CertianConditions/1_Loops';
// import './3_CertianConditions/2_Statements';

// import './4_Functions/1_FnCreation';
// import './4_Functions/2_FnParameters';
// import './4_Functions/3_RestAndSpread';
// import './4_Functions/4_PureAndImpureFn';
// import './4_Functions/5_ArrowFn';
// import './4_Functions/6_FnAsArgument';
// import './4_Functions/7_IIFE';
// import './4_Functions/8_FnOverloading';
import './4_Functions/9_Assignment';