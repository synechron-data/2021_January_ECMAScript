function Add() {

}

console.log(Add(2, 3));
console.log(Add(2, 3, 4));

try {
    console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments
} catch (e) {
    console.error(e.message);
} finally {
    console.log("Finally will always Run");
}