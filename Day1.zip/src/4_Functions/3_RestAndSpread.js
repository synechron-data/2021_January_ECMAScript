// If I use ... on Lefthand side of assignment operator (Rest)
// If I use ... on Righthand side of assignment operator (Spread)

// In ECMAScript 2015, we can use ... only with Arrays
// In ECMAScript 2018, we can use ... only with Objects

// ----------------------------------------------------------------- Array Spread

// var arr1 = [10, 20, 30, 40, [50, 60, 70, 80, 90]];

// var arr2 = arr1;

// Shallow Copy
// var arr2 = arr1.slice();
// var arr2 = [].concat(arr1);
// var arr2 = [...arr1];

// Deep Copy
// var arr2 = JSON.parse(JSON.stringify(arr1));

// arr2[0] = 1000;
// arr2[4][0] = 5000;

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// ---------------------------

// var arr1 = [10, 20, 30, 40];
// var arr2 = [50, 60, 70, 80];

// var arr3 = [].concat(arr1, arr2);
// var arr4 = arr1.concat(arr2);
// var arr5 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);
// console.log("Array 4", arr4);
// console.log("Array 5", arr5);

// ----------------------------------------------------------------- Array Destructuring & Rest

var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// ES5 - Destructuring
// var x = arr[0];
// var y = arr[2];

// ECMAScript 2015 - Destructuring
// var [x, y] = arr;
// var [x, , y] = arr;

// console.log(`x = ${x}, y = ${y}`);

// Array Destructuring with Rest - ECMAScript 2015
// var [x, y, ...z] = arr;
var [x, , y, ...z] = arr;

console.log(`x = ${x}, y = ${y}, z = ${z}`);